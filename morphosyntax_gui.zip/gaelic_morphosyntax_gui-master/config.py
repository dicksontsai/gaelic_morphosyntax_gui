language = "Gaelic"
dictionary_website = "http://www.cairnwater.co.uk/gaelicdictionary/index.aspx?Language=en"